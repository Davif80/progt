"""
URL configuration for app project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from .views import (fcliente, cadastrarCliente,
                    loginCliente, cadProduto,
                    cadastrar, mostrarDados,
                    editarProduto, deleteProduto,
                    voltarDados, updateProduto,
                    comprar, finalizar, imprimir,
                    login2, botContato, enviarCont, botNossaloja)

urlpatterns = [
   path('', fcliente),
   path('cadastrarCliente', cadastrarCliente, name='cadastrarCliente'),
   path('loginCliente', loginCliente, name='loginCliente'),
   path('cadProduto', cadProduto, name='cadProduto'),
   path('cadastrar', cadastrar, name='cadastrar'),
   path('mostrarDados', mostrarDados, name='mostrarDados'),
   path('editarProduto/<int:id>', editarProduto, name='editarProduto'),
   path('deleteProduto/<int:id>', deleteProduto, name='deleteProduto'),
   path('voltarDados', voltarDados, name='voltarDados'),
   path('updateProduto/<int:id>', updateProduto, name='updateProduto'),
   path('comprar/<int:id>', comprar, name='comprar'),
   path('finalizar', finalizar, name='finalizar'),
   path('imprimir/<str:pFinal>', imprimir, name='imprimir'),
   path('login2', login2, name='login2'),
   path('botContato', botContato, name='botContato'),
   path('enviarCont', enviarCont, name='enviarCont'),
   path('botNossaloja',botNossaloja,name='botNossaloja')
]
