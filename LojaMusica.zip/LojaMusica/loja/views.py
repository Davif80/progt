from django.shortcuts import render, redirect
from .models import Cliente, Produto, Carrinho, Finalizar, Contato
from django.contrib import messages
# Create your views here.
def fcliente(request):
    nome = 'Conta'
    return render(request, 'index.html', {"nome": nome})

def login2(request):
    return render(request, 'login2.html')

#pagina login/cadastrar
def cadastrarCliente(request):
    cli_nome = request.POST.get("nome")
    cli_telefone = request.POST.get("telefone")
    cli_cpf = request.POST.get("cpf")
    cli_email = request.POST.get("email")
    cli_senha = request.POST.get("senha")
    if Cliente.objects.filter(cpf=cli_cpf).exists():
        msg = 1
        return render(request, 'login2.html', {"msg": msg})
    else:
        Cliente.objects.create(nome=cli_nome, telefone=cli_telefone, cpf=cli_cpf, email=cli_email, senha=cli_senha)
        msg = 3
        return render(request, 'login2.html', {"msg": msg})
    
def loginCliente(request):
    cli_cpf = request.POST.get("cpf")
    cli_senha = request.POST.get("senha")
    clientes = Cliente.objects.all()
    if cli_cpf == "12917266759" and cli_senha == "admin":
        return render(request, 'admin_cliente.html')
    elif Cliente.objects.filter(cpf=cli_cpf, senha=cli_senha).exists():
        cliente = Cliente.objects.get(cpf=cli_cpf, senha=cli_senha)
        nome = cliente.nome
        value = 1
        produtos = Produto.objects.all()
        return render(request, 'index.html', {"produtos": produtos, "nome": nome, "value": value})
    else:
        msg = 2
        return render(request, 'login2.html', {"msg": msg})

#pagina admin
def cadProduto(request):
    return render(request, 'cadastrar_produto.html')

def cadastrar(request):
    nome_prod = request.POST.get("nome_produto")
    tipo_prod = request.POST.get("tipo")
    qtd_prod = request.POST.get("qtd")
    preco_prod = request.POST.get("preco")
    descricao_prod = request.POST.get("descricao")
    Produto.objects.create(nome_produto=nome_prod, tipo=tipo_prod, qtd=qtd_prod, preco=preco_prod, descricao=descricao_prod)
    return render(request, 'cadastrar_produto.html')

def mostrarDados(request):
    produtos = Produto.objects.all()
    return render(request, 'mostrar_dados.html', {"produtos": produtos})

#pagina de edição dos produtos
def voltarDados(request):
    return render(request, 'admin_cliente.html')

def editarProduto(request, id):
    produtos = Produto.objects.get(id=id)
    return render(request, 'editar_Produto.html', {"produtos": produtos})

def deleteProduto(request, id):
    produto = Produto.objects.get(id=id)
    produto.delete()
    return redirect(mostrarDados)

def updateProduto(request, id):
    nome_prod = request.POST.get("nome_produto")
    tipo_prod = request.POST.get("tipo")
    qtd_prod = request.POST.get("qtd")
    preco_prod = request.POST.get("preco")
    descricao_prod = request.POST.get("descricao")
    produto = Produto.objects.get(id=id)
    produto.nome_produto = nome_prod
    produto.qtd = qtd_prod
    produto.tipo = tipo_prod
    produto.preco = preco_prod
    produto.descricao = descricao_prod
    produto.save()
    return redirect(mostrarDados)

#def carrinho(request):
  #  produtos = Produto.objects.all()
  #  return render(request, 'home_cliente.html', {'produtos': produtos})

#carrinho
def comprar(request, id):
    produto = Produto.objects.get(id=id)
    Carrinho.objects.create(nome_produto=produto.nome_produto, quant=produto.qtd, preco=produto.preco)
    produtos = Produto.objects.all()
    return render(request, 'home_cliente.html', {"produtos": produtos})

def finalizar(request):
    preco_total = sum(item.preco for item in Carrinho.objects.all())
    carrinho = Carrinho.objects.all()
    Finalizar.objects.all().delete()
    for item in carrinho:
        Finalizar.objects.create(
            nome_produto=item.nome_produto,
            quant=item.quant,
            preco=item.preco,
            preco_final=preco_total)
    produtos = Finalizar.objects.all()
    return render(request, 'finalizar.html', {"produtos": produtos, "preco_final": preco_total})

def imprimir(request, pFinal):
    produtos = list(Finalizar.objects.all())
    Finalizar.objects.all().delete()
    Carrinho.objects.all().delete()
    return render(request, 'nota_fiscal.html', {"produtos": produtos, "preco_final": pFinal})


# contato
def botContato(request):
    return render(request, 'contato.html')

def enviarCont(request):
    cnome = request.POST.get("nome")
    cemail = request.POST.get("email")
    cassunto = request.POST.get("assunto")
    cmensagem = request.POST.get("mensagem")
    Contato.objects.create(nome=cnome, email=cemail, assunto=cassunto, mensagem=cmensagem)
    msg = 1
    return render(request, 'index.html', {"msg":msg})

def botNossaloja(request):
    return render(request, 'nossa_loja.html')
# relatorio dos produtos
#def relatProd(request):
  #  return